-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Авг 01 2014 г., 16:26
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `urlchecker`
--

-- --------------------------------------------------------

--
-- Структура таблицы `app2platforms`
--

CREATE TABLE IF NOT EXISTS `app2platforms` (
  `id_application` int(11) NOT NULL,
  `id_platform` int(11) NOT NULL,
  PRIMARY KEY (`id_application`,`id_platform`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `app2platforms`
--

INSERT INTO `app2platforms` (`id_application`, `id_platform`) VALUES
(1, 11),
(1, 14),
(2, 11),
(2, 14),
(3, 10),
(3, 13),
(5, 11),
(5, 13),
(5, 15),
(6, 10),
(6, 11),
(6, 14),
(6, 15);

-- --------------------------------------------------------

--
-- Структура таблицы `applications`
--

CREATE TABLE IF NOT EXISTS `applications` (
  `id_application` tinyint(5) NOT NULL AUTO_INCREMENT,
  `name_application` varchar(255) NOT NULL,
  `url_application` varchar(255) NOT NULL,
  `description_application` text NOT NULL,
  `id_user` tinyint(5) NOT NULL,
  PRIMARY KEY (`id_application`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `applications`
--

INSERT INTO `applications` (`id_application`, `name_application`, `url_application`, `description_application`, `id_user`) VALUES
(1, 'Yandex', 'http://www.yandex.ru', '', 1),
(2, 'Google', 'http://google.com', '', 1),
(3, 'Habr', 'http://habrahabr.ru', 'dsfsdf', 1),
(4, 'test66112------!!!!!', 'werwrwerwerwer', '', 4),
(5, '1111', '2222', '', 4),
(6, '444', '55555', '', 4);

-- --------------------------------------------------------

--
-- Структура таблицы `check_log`
--

CREATE TABLE IF NOT EXISTS `check_log` (
  `id_check_log` int(11) NOT NULL AUTO_INCREMENT,
  `id_application` tinyint(5) NOT NULL,
  `id_platform` tinyint(5) NOT NULL,
  `HTTP_code` varchar(255) NOT NULL,
  `date_check` datetime NOT NULL,
  `id_user` smallint(5) NOT NULL,
  `size_download` int(11) NOT NULL,
  `download_content_length` int(11) NOT NULL,
  `redirect_url` text NOT NULL,
  `request_header` text NOT NULL,
  PRIMARY KEY (`id_check_log`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Дамп данных таблицы `check_log`
--

INSERT INTO `check_log` (`id_check_log`, `id_application`, `id_platform`, `HTTP_code`, `date_check`, `id_user`, `size_download`, `download_content_length`, `redirect_url`, `request_header`) VALUES
(1, 3, 10, 'CURLE_COULDNT_RESOLVE_HOST', '2014-08-01 12:40:28', 1, 0, 0, '', ''),
(2, 1, 11, '200', '2014-08-01 12:40:30', 1, 47448, 47448, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n'),
(3, 1, 14, '200', '2014-08-01 12:40:31', 1, 47430, 47430, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n'),
(4, 2, 11, '301', '2014-08-01 12:40:33', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(5, 2, 14, '301', '2014-08-01 12:40:34', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(6, 3, 13, 'CURLE_COULDNT_RESOLVE_HOST', '2014-08-01 12:40:37', 1, 0, 0, '', ''),
(7, 3, 10, 'CURLE_COULDNT_RESOLVE_HOST', '2014-08-01 12:40:40', 1, 0, 0, '', ''),
(8, 1, 11, '200', '2014-08-01 12:40:41', 1, 47345, 47345, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n'),
(9, 1, 14, '200', '2014-08-01 12:40:41', 1, 47357, 47357, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n'),
(10, 2, 14, '301', '2014-08-01 12:40:42', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(11, 3, 10, 'CURLE_COULDNT_RESOLVE_HOST', '2014-08-01 12:40:45', 1, 0, 0, '', ''),
(12, 2, 11, '301', '2014-08-01 12:40:46', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(13, 2, 14, '301', '2014-08-01 12:40:46', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(14, 1, 14, '200', '2014-08-01 12:40:48', 1, 52436, 52436, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n'),
(15, 3, 10, 'CURLE_COULDNT_RESOLVE_HOST', '2014-08-01 12:41:27', 1, 0, 0, '', ''),
(16, 3, 13, 'CURLE_COULDNT_RESOLVE_HOST', '2014-08-01 12:41:31', 1, 0, 0, '', ''),
(17, 2, 11, '301', '2014-08-01 12:41:32', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(18, 1, 11, '200', '2014-08-01 12:41:32', 1, 47411, 47411, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n'),
(19, 1, 14, '200', '2014-08-01 12:41:33', 1, 47429, 47429, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n'),
(20, 2, 14, '301', '2014-08-01 12:41:34', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(21, 3, 10, '200', '2014-08-01 12:42:57', 1, 17329, -1, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: habrahabr.ru\r\nAccept: */*\r\n\r\n'),
(22, 3, 13, '200', '2014-08-01 12:42:58', 1, 17329, -1, '', 'GET / HTTP/1.1\r\nUser-Agent: 66666\r\nHost: habrahabr.ru\r\nAccept: */*\r\n\r\n'),
(23, 2, 11, '301', '2014-08-01 12:43:00', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(24, 1, 11, '200', '2014-08-01 12:43:01', 1, 47496, 47496, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n'),
(25, 1, 14, '200', '2014-08-01 12:43:01', 1, 47569, 47569, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n'),
(26, 2, 14, '301', '2014-08-01 12:43:03', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(27, 3, 13, '200', '2014-08-01 12:43:03', 1, 17250, -1, '', 'GET / HTTP/1.1\r\nUser-Agent: 66666\r\nHost: habrahabr.ru\r\nAccept: */*\r\n\r\n'),
(28, 3, 10, '200', '2014-08-01 12:43:04', 1, 17250, -1, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: habrahabr.ru\r\nAccept: */*\r\n\r\n'),
(29, 2, 11, '301', '2014-08-01 12:43:05', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(30, 1, 11, '200', '2014-08-01 12:43:06', 1, 47410, 47410, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n'),
(31, 1, 14, '200', '2014-08-01 12:43:06', 1, 47587, 47587, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n'),
(32, 2, 14, '301', '2014-08-01 12:43:07', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(33, 3, 10, '200', '2014-08-01 16:12:14', 1, 17192, -1, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: habrahabr.ru\r\nAccept: */*\r\n\r\n'),
(34, 2, 11, '301', '2014-08-01 16:12:16', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(35, 1, 11, '200', '2014-08-01 16:12:17', 1, 47906, 47906, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n'),
(36, 1, 14, '200', '2014-08-01 16:12:18', 1, 47856, 47856, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n'),
(37, 2, 14, '301', '2014-08-01 16:12:18', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(38, 2, 11, '301', '2014-08-01 16:12:23', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(39, 3, 13, '200', '2014-08-01 16:12:23', 1, 17184, -1, '', 'GET / HTTP/1.1\r\nUser-Agent: 66666\r\nHost: habrahabr.ru\r\nAccept: */*\r\n\r\n'),
(40, 2, 14, '301', '2014-08-01 16:12:24', 1, 219, 219, 'http://www.google.com/', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: google.com\r\nAccept: */*\r\n\r\n'),
(41, 1, 14, '200', '2014-08-01 16:12:25', 1, 47907, 47907, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n'),
(42, 1, 11, '200', '2014-08-01 16:12:34', 1, 47905, 47905, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n');

-- --------------------------------------------------------

--
-- Структура таблицы `platforms`
--

CREATE TABLE IF NOT EXISTS `platforms` (
  `id_platform` tinyint(5) NOT NULL AUTO_INCREMENT,
  `name_platform` varchar(50) NOT NULL,
  `UA_string` text NOT NULL,
  `description_platform` text NOT NULL,
  PRIMARY KEY (`id_platform`),
  UNIQUE KEY `unique_id_platform` (`id_platform`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Дамп данных таблицы `platforms`
--

INSERT INTO `platforms` (`id_platform`, `name_platform`, `UA_string`, `description_platform`) VALUES
(8, 'NetCast 2.0', 'Mozilla/5.0 (DirectFB; U; Linux mips; en) AppleWebKit/531.2+ (KHTML, like Gecko, Safari/531.2+); LG Browser/4.0.9(+mouse+3D+SCREEN+TUNER; LGE; 42LE7500-ZA; 03.05.04; 0x00000001;); LG NetCast.TV-2011', ''),
(9, 'NetCast 3.0 H12 (2012)', 'Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ LG Browser/5.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT4; 09.00.00; 0x00000001;); LG NetCast.TV-2012', ''),
(10, 'NetCast 3.0 M12 (2012)', '33333', ''),
(11, 'NetCast 4.0 H13 (2013)', 'Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)', ''),
(12, 'NetCast 4.0 M13 (2013)', 'Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)', ''),
(13, 'NetCast 4.5 (2014)', '66666', ''),
(14, 'WebOS Full HD (FHD)', 'Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41', ''),
(15, 'webOS Ultra HD (UHD)', 'Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41', ''),
(18, 'adsasd', 'asdasd', '');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id_user` tinyint(5) NOT NULL AUTO_INCREMENT,
  `login_user` varchar(50) NOT NULL,
  `password_user` varchar(50) NOT NULL,
  `email_user` varchar(255) NOT NULL,
  `superuser` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_user`, `login_user`, `password_user`, `email_user`, `superuser`) VALUES
(1, 'admin', 'e00cf25ad42683b3df678c61f42c6bda', 'test@test.test', 1),
(3, 'user', 'c84258e9c39059a89ab77d846ddab909', '', 0),
(4, 'admin6611', '96e79218965eb72c92a549dd5a330112', 'tesd@sdffsd.ru', 0),
(5, 'test', '277f5e98696c0299c215aa15584c05a4', 'test@test.test', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
