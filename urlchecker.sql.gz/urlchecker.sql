-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Авг 08 2014 г., 16:46
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `urlchecker`
--

-- --------------------------------------------------------

--
-- Структура таблицы `app2platforms`
--

CREATE TABLE IF NOT EXISTS `app2platforms` (
  `id_application` int(11) NOT NULL,
  `id_platform` int(11) NOT NULL,
  PRIMARY KEY (`id_application`,`id_platform`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `app2platforms`
--

INSERT INTO `app2platforms` (`id_application`, `id_platform`) VALUES
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(1, 13),
(1, 14),
(1, 15),
(2, 11),
(2, 14),
(8, 8),
(8, 9),
(8, 10),
(8, 11),
(8, 12),
(8, 13),
(8, 14),
(8, 15);

-- --------------------------------------------------------

--
-- Структура таблицы `applications`
--

CREATE TABLE IF NOT EXISTS `applications` (
  `id_application` tinyint(5) NOT NULL AUTO_INCREMENT,
  `name_application` varchar(255) NOT NULL,
  `url_application` varchar(255) NOT NULL,
  `description_application` text NOT NULL,
  `id_user` tinyint(5) NOT NULL,
  PRIMARY KEY (`id_application`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Дамп данных таблицы `applications`
--

INSERT INTO `applications` (`id_application`, `name_application`, `url_application`, `description_application`, `id_user`) VALUES
(1, 'Yandex', 'http://yandex.ru', '', 1),
(2, 'Google', 'http://google.com', '', 1),
(8, 'LG Cinema Russia', 'http://app.lgerp.ru/apps/lgcinema/?id=211', '', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `check_log`
--

CREATE TABLE IF NOT EXISTS `check_log` (
  `id_check_log` int(11) NOT NULL AUTO_INCREMENT,
  `id_application` tinyint(5) NOT NULL,
  `id_platform` tinyint(5) NOT NULL,
  `HTTP_code` varchar(255) NOT NULL,
  `date_check` datetime NOT NULL,
  `id_user` smallint(5) NOT NULL,
  `size_download` int(11) NOT NULL,
  `download_content_length` int(11) NOT NULL,
  `redirect_url` text NOT NULL,
  `request_header` text NOT NULL,
  `weight_diff` int(13) NOT NULL,
  PRIMARY KEY (`id_check_log`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=299 ;

--
-- Дамп данных таблицы `check_log`
--

INSERT INTO `check_log` (`id_check_log`, `id_application`, `id_platform`, `HTTP_code`, `date_check`, `id_user`, `size_download`, `download_content_length`, `redirect_url`, `request_header`, `weight_diff`) VALUES
(56, 2, 14, '200', '2014-08-04 13:12:12', 1, 56828, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', -30),
(55, 1, 15, '200', '2014-08-04 13:12:08', 1, 47483, 47483, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 615),
(54, 1, 14, '200', '2014-08-04 13:12:07', 1, 47542, 47542, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 43),
(53, 1, 11, '200', '2014-08-04 13:12:06', 1, 47608, 47608, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 69),
(12, 1, 11, '200', '2014-08-04 10:19:02', 1, 46765, 46765, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 46765),
(13, 1, 14, '200', '2014-08-04 10:24:46', 1, 47049, 47049, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 47049),
(14, 1, 14, '200', '2014-08-04 10:24:50', 1, 46869, 46869, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -180),
(15, 1, 11, '200', '2014-08-04 10:24:51', 1, 46971, 46971, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 206),
(16, 1, 11, '200', '2014-08-04 11:02:34', 1, 46899, 46899, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -72),
(17, 1, 11, '200', '2014-08-04 11:02:35', 1, 46818, 46818, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -81),
(18, 1, 14, '200', '2014-08-04 11:02:36', 1, 46801, 46801, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -68),
(19, 1, 11, '200', '2014-08-04 11:02:37', 1, 46755, 46755, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -63),
(20, 1, 14, '200', '2014-08-04 11:02:38', 1, 51702, 51702, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4901),
(21, 1, 11, '200', '2014-08-04 11:02:39', 1, 51696, 51696, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4941),
(22, 1, 10, '200', '2014-08-04 11:02:47', 1, 46859, 46859, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 46859),
(23, 1, 15, '200', '2014-08-04 11:02:48', 1, 46754, 46754, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 46754),
(24, 1, 10, '200', '2014-08-04 11:02:52', 1, 46866, 46866, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 7),
(25, 1, 15, '200', '2014-08-04 11:02:53', 1, 46868, 46868, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 114),
(28, 2, 14, '200', '2014-08-04 11:37:39', 1, 56888, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 56888),
(29, 2, 11, '200', '2014-08-04 11:37:41', 1, 56784, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 56784),
(30, 2, 11, '200', '2014-08-04 11:37:44', 1, 56796, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 12),
(31, 2, 14, '200', '2014-08-04 11:37:46', 1, 56800, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', -88),
(32, 2, 14, '200', '2014-08-04 11:37:50', 1, 56858, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 58),
(52, 1, 11, '200', '2014-08-04 13:12:04', 1, 47539, 47539, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -68),
(51, 1, 14, '200', '2014-08-04 13:12:02', 1, 47499, 47499, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4203),
(50, 1, 11, '200', '2014-08-04 13:11:58', 1, 47607, 47607, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4089),
(48, 1, 10, '200', '2014-08-04 12:41:46', 1, 47423, 47423, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 557),
(49, 1, 10, '200', '2014-08-04 13:11:56', 1, 47655, 47655, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 232),
(57, 2, 11, '200', '2014-08-04 13:12:14', 1, 56802, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 6),
(58, 1, 10, '200', '2014-08-04 14:17:54', 1, 47847, 47847, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 192),
(59, 1, 10, '200', '2014-08-04 14:17:56', 1, 52642, 52642, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4795),
(60, 1, 10, '200', '2014-08-04 14:17:57', 1, 47797, 47797, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4845),
(61, 1, 10, '200', '2014-08-04 14:17:58', 1, 47799, 47799, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 2),
(62, 1, 10, '200', '2014-08-04 14:18:00', 1, 47749, 47749, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -50),
(63, 1, 10, '200', '2014-08-04 14:18:01', 1, 47933, 47933, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 184),
(64, 1, 10, '200', '2014-08-04 14:18:02', 1, 47771, 47771, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -162),
(65, 1, 10, '200', '2014-08-04 14:18:03', 1, 47910, 47910, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 139),
(66, 1, 10, '200', '2014-08-04 14:18:05', 1, 47792, 47792, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -118),
(67, 1, 10, '200', '2014-08-04 14:18:06', 1, 47940, 47940, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 148),
(68, 1, 10, '200', '2014-08-04 14:18:06', 1, 47929, 47929, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -11),
(69, 1, 10, '200', '2014-08-04 14:18:07', 1, 47885, 47885, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -44),
(70, 1, 10, '200', '2014-08-04 14:18:08', 1, 47923, 47923, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 38),
(71, 1, 10, '200', '2014-08-04 14:18:08', 1, 47800, 47800, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -123),
(72, 1, 10, '200', '2014-08-04 14:18:09', 1, 52780, 52780, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4980),
(73, 1, 11, '200', '2014-08-04 14:18:10', 1, 47823, 47823, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 215),
(74, 1, 14, '200', '2014-08-04 14:18:11', 1, 47940, 47940, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 398),
(75, 1, 15, '200', '2014-08-04 14:18:12', 1, 47769, 47769, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 286),
(76, 1, 11, '200', '2014-08-04 14:20:30', 1, 47654, 47654, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -169),
(77, 1, 10, '200', '2014-08-04 14:20:31', 1, 47760, 47760, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -5020),
(78, 1, 11, '200', '2014-08-04 14:20:50', 1, 47662, 47662, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 8),
(79, 1, 10, '200', '2014-08-04 14:20:52', 1, 47735, 47735, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -25),
(80, 2, 14, '200', '2014-08-04 14:20:57', 1, 56830, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 2),
(81, 2, 11, '200', '2014-08-04 14:20:59', 1, 56758, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', -44),
(82, 1, 14, '200', '2014-08-04 14:21:01', 1, 52615, 52615, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4675),
(83, 1, 15, '200', '2014-08-04 14:21:01', 1, 47635, 47635, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -134),
(84, 1, 10, '200', '2014-08-04 14:21:40', 1, 47780, 47780, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 45),
(85, 1, 11, '200', '2014-08-04 14:21:42', 1, 47680, 47680, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 18),
(86, 1, 14, '200', '2014-08-04 14:21:43', 1, 47714, 47714, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4901),
(87, 1, 15, '200', '2014-08-04 14:21:44', 1, 47799, 47799, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 164),
(88, 2, 11, '200', '2014-08-04 14:21:48', 1, 56862, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 104),
(89, 1, 11, '200', '2014-08-04 14:22:42', 1, 47652, 47652, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -28),
(90, 1, 10, '200', '2014-08-04 14:24:18', 1, 52667, 52667, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4887),
(91, 1, 11, '200', '2014-08-04 14:24:20', 1, 47704, 47704, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 52),
(92, 1, 14, '200', '2014-08-04 14:24:22', 1, 52574, 52574, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4860),
(93, 1, 10, '200', '2014-08-04 14:24:49', 1, 47833, 47833, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4834),
(94, 1, 10, '200', '2014-08-04 14:24:50', 1, 47782, 47782, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -51),
(95, 1, 10, '200', '2014-08-04 14:27:23', 1, 47842, 47842, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 60),
(96, 1, 11, '200', '2014-08-04 14:27:28', 1, 47697, 47697, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -7),
(97, 1, 14, '200', '2014-08-04 14:27:30', 1, 47736, 47736, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4838),
(98, 1, 15, '200', '2014-08-04 14:27:31', 1, 47675, 47675, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -124),
(99, 1, 15, '200', '2014-08-04 14:27:32', 1, 47759, 47759, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 84),
(100, 1, 11, '200', '2014-08-04 14:27:35', 1, 47825, 47825, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 128),
(101, 1, 10, '200', '2014-08-04 14:27:37', 1, 47758, 47758, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -84),
(102, 1, 10, '200', '2014-08-04 14:27:45', 1, 47775, 47775, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 17),
(103, 1, 10, '200', '2014-08-04 14:27:47', 1, 47759, 47759, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -16),
(104, 1, 11, '200', '2014-08-04 14:30:02', 1, 47591, 47591, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -234),
(105, 1, 11, '200', '2014-08-04 14:30:04', 1, 47512, 47512, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -79),
(106, 1, 10, '200', '2014-08-04 14:30:22', 1, 47581, 47581, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -178),
(107, 1, 11, '200', '2014-08-04 14:30:23', 1, 47659, 47659, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 147),
(108, 1, 14, '200', '2014-08-04 14:30:24', 1, 47590, 47590, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -146),
(109, 1, 15, '200', '2014-08-04 14:30:26', 1, 47678, 47678, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -81),
(110, 1, 15, '200', '2014-08-04 14:30:27', 1, 47611, 47611, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -67),
(111, 1, 10, '200', '2014-08-04 14:36:15', 1, 47478, 47478, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -103),
(112, 1, 10, '200', '2014-08-04 14:36:25', 1, 47472, 47472, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -6),
(113, 1, 11, '200', '2014-08-04 14:36:28', 1, 47500, 47500, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -159),
(114, 1, 14, '200', '2014-08-04 14:36:28', 1, 47425, 47425, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -165),
(115, 1, 15, '200', '2014-08-04 14:36:29', 1, 47534, 47534, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -77),
(116, 1, 11, '200', '2014-08-04 14:36:31', 1, 47453, 47453, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -47),
(117, 1, 11, '200', '2014-08-04 14:36:32', 1, 47444, 47444, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -9),
(118, 1, 11, '200', '2014-08-04 14:36:33', 1, 47446, 47446, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 2),
(119, 1, 11, '200', '2014-08-04 14:36:34', 1, 47544, 47544, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 98),
(120, 1, 10, '200', '2014-08-04 14:36:35', 1, 47417, 47417, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -55),
(121, 1, 10, '200', '2014-08-04 14:36:58', 1, 52310, 52310, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4893),
(122, 1, 10, '200', '2014-08-04 14:37:00', 1, 47498, 47498, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4812),
(123, 1, 10, '200', '2014-08-04 14:37:09', 1, 47452, 47452, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -46),
(124, 1, 10, '200', '2014-08-04 14:37:11', 1, 47433, 47433, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -19),
(125, 1, 10, '200', '2014-08-04 14:37:12', 1, 47490, 47490, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 57),
(126, 1, 10, '200', '2014-08-04 14:37:13', 1, 47424, 47424, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -66),
(127, 1, 10, '200', '2014-08-04 14:37:14', 1, 47430, 47430, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 6),
(128, 1, 10, '200', '2014-08-04 14:37:16', 1, 47504, 47504, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 74),
(129, 1, 10, '200', '2014-08-04 14:37:22', 1, 47424, 47424, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -80),
(130, 1, 10, '200', '2014-08-04 14:37:22', 1, 47438, 47438, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 14),
(131, 1, 10, '200', '2014-08-04 14:37:26', 1, 52353, 52353, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4915),
(132, 1, 10, '200', '2014-08-04 14:37:27', 1, 47440, 47440, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4913),
(133, 1, 10, '200', '2014-08-04 14:37:28', 1, 47478, 47478, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 38),
(134, 1, 10, '200', '2014-08-04 14:37:29', 1, 47608, 47608, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 130),
(135, 1, 10, '200', '2014-08-04 14:37:30', 1, 47562, 47562, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -46),
(136, 1, 11, '200', '2014-08-04 14:37:31', 1, 47460, 47460, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -84),
(137, 1, 14, '200', '2014-08-04 14:37:32', 1, 52284, 52284, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4859),
(138, 1, 15, '200', '2014-08-04 14:37:33', 1, 47380, 47380, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -154),
(139, 1, 10, '200', '2014-08-04 14:37:47', 1, 47577, 47577, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 15),
(140, 1, 11, '200', '2014-08-04 14:37:48', 1, 47538, 47538, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 78),
(141, 1, 14, '200', '2014-08-04 14:37:50', 1, 47414, 47414, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4870),
(142, 1, 10, '200', '2014-08-04 14:38:26', 1, 47564, 47564, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -13),
(143, 1, 11, '200', '2014-08-04 14:38:28', 1, 47526, 47526, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -12),
(144, 1, 10, '200', '2014-08-04 14:38:31', 1, 47533, 47533, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -31),
(145, 1, 11, '200', '2014-08-04 14:38:32', 1, 47440, 47440, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -86),
(146, 1, 10, '200', '2014-08-04 14:38:33', 1, 47485, 47485, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -48),
(147, 1, 11, '200', '2014-08-04 14:38:35', 1, 47502, 47502, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 62),
(148, 1, 10, '200', '2014-08-04 14:38:36', 1, 47486, 47486, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 1),
(149, 1, 11, '200', '2014-08-04 14:38:37', 1, 47548, 47548, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 46),
(150, 1, 10, '200', '2014-08-04 14:38:37', 1, 47583, 47583, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 97),
(151, 1, 11, '200', '2014-08-04 14:38:39', 1, 47386, 47386, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -162),
(152, 1, 11, '200', '2014-08-04 14:38:40', 1, 47654, 47654, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 268),
(153, 1, 10, '200', '2014-08-04 14:39:13', 1, 47531, 47531, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -52),
(154, 1, 10, '200', '2014-08-04 14:39:30', 1, 47533, 47533, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 2),
(155, 1, 11, '200', '2014-08-04 14:39:31', 1, 47514, 47514, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -140),
(156, 1, 14, '200', '2014-08-04 14:39:33', 1, 47480, 47480, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 66),
(157, 1, 15, '200', '2014-08-04 14:39:34', 1, 47421, 47421, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 41),
(158, 2, 11, '200', '2014-08-04 14:39:37', 1, 56872, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 10),
(159, 2, 14, '200', '2014-08-04 14:39:40', 1, 60037, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 3207),
(160, 2, 11, '200', '2014-08-04 14:39:42', 1, 56732, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', -140),
(161, 1, 11, '200', '2014-08-04 14:39:43', 1, 47540, 47540, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 26),
(162, 1, 10, '200', '2014-08-04 14:39:43', 1, 47506, 47506, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -27),
(163, 1, 14, '200', '2014-08-04 14:39:44', 1, 47479, 47479, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -1),
(164, 2, 14, '200', '2014-08-04 14:39:46', 1, 56910, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', -3127),
(165, 1, 15, '200', '2014-08-04 14:39:47', 1, 47525, 47525, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 104),
(166, 2, 14, '200', '2014-08-04 14:39:51', 1, 56942, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 32),
(167, 1, 14, '200', '2014-08-04 14:39:53', 1, 52299, 52299, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4820),
(168, 1, 15, '200', '2014-08-04 14:39:54', 1, 47465, 47465, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -60),
(169, 1, 10, '200', '2014-08-04 14:42:39', 1, 52436, 52436, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4930),
(170, 1, 10, '200', '2014-08-04 14:42:40', 1, 47710, 47710, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4726),
(171, 1, 11, '200', '2014-08-04 14:42:42', 1, 52442, 52442, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4902),
(172, 1, 14, '200', '2014-08-04 14:42:44', 1, 47654, 47654, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4645),
(173, 1, 14, '200', '2014-08-04 14:42:46', 1, 47630, 47630, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -24),
(174, 1, 15, '200', '2014-08-04 14:42:47', 1, 47713, 47713, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 248),
(175, 1, 11, '200', '2014-08-04 14:45:30', 1, 47621, 47621, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4821),
(176, 1, 11, '200', '2014-08-04 14:45:31', 1, 47546, 47546, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -75),
(177, 2, 11, '200', '2014-08-04 14:45:35', 1, 56826, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 94),
(178, 1, 14, '200', '2014-08-04 14:45:36', 1, 47551, 47551, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -79),
(179, 2, 14, '200', '2014-08-04 14:45:38', 1, 56732, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', -210),
(180, 1, 15, '200', '2014-08-04 14:45:39', 1, 47556, 47556, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -157),
(181, 1, 10, '200', '2014-08-04 14:45:42', 1, 47555, 47555, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -155),
(182, 1, 10, '200', '2014-08-04 14:50:42', 1, 47683, 47683, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 128),
(183, 1, 11, '200', '2014-08-04 14:50:43', 1, 47582, 47582, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 36),
(184, 1, 14, '200', '2014-08-04 14:50:45', 1, 47623, 47623, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 72),
(185, 1, 15, '200', '2014-08-04 14:50:46', 1, 47627, 47627, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 71),
(186, 2, 11, '200', '2014-08-04 14:50:49', 1, 56830, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 4),
(187, 2, 14, '200', '2014-08-04 14:50:52', 1, 56824, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 92),
(188, 1, 10, '200', '2014-08-04 14:51:10', 1, 47551, 47551, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -132),
(189, 1, 11, '200', '2014-08-04 14:51:12', 1, 47624, 47624, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 42),
(190, 1, 14, '200', '2014-08-04 14:51:14', 1, 47701, 47701, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 78),
(191, 2, 14, '200', '2014-08-04 14:51:17', 1, 56814, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', -10),
(192, 2, 14, '200', '2014-08-04 14:51:20', 1, 56814, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 0),
(193, 1, 10, '200', '2014-08-04 14:51:31', 1, 47610, 47610, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 59),
(194, 1, 10, '200', '2014-08-04 14:52:33', 1, 47690, 47690, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 80),
(195, 1, 10, '200', '2014-08-04 14:52:35', 1, 47601, 47601, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -89),
(196, 1, 11, '200', '2014-08-04 14:53:09', 1, 47681, 47681, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 57),
(197, 1, 11, '200', '2014-08-04 14:53:11', 1, 47746, 47746, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 65),
(198, 2, 11, '200', '2014-08-04 14:53:15', 1, 56878, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 48),
(199, 1, 14, '200', '2014-08-04 14:53:19', 1, 47647, 47647, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -54),
(200, 1, 15, '200', '2014-08-04 14:53:21', 1, 52566, 52566, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4939),
(201, 1, 15, '200', '2014-08-04 14:53:23', 1, 47615, 47615, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4951),
(202, 1, 15, '200', '2014-08-04 14:53:25', 1, 47658, 47658, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 43),
(203, 1, 15, '200', '2014-08-04 14:53:28', 1, 47639, 47639, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -19),
(204, 1, 11, '200', '2014-08-04 14:54:51', 1, 47660, 47660, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -86),
(205, 1, 14, '200', '2014-08-04 14:54:52', 1, 47769, 47769, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 122),
(206, 1, 10, '200', '2014-08-04 14:55:35', 1, 47653, 47653, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 52),
(207, 1, 11, '200', '2014-08-04 14:55:37', 1, 47848, 47848, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 188),
(208, 1, 11, '200', '2014-08-04 14:55:39', 1, 47708, 47708, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -140),
(209, 1, 11, '200', '2014-08-04 14:55:41', 1, 47793, 47793, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 85),
(210, 1, 15, '200', '2014-08-04 14:55:42', 1, 47707, 47707, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 68),
(211, 1, 15, '200', '2014-08-04 14:55:44', 1, 47717, 47717, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 10),
(212, 1, 14, '200', '2014-08-04 14:55:45', 1, 47752, 47752, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -17),
(213, 1, 14, '200', '2014-08-04 14:55:47', 1, 47685, 47685, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -67),
(214, 1, 14, '200', '2014-08-04 14:55:48', 1, 47787, 47787, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 102),
(215, 1, 14, '200', '2014-08-04 14:55:54', 1, 47661, 47661, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -126),
(216, 1, 14, '200', '2014-08-04 14:55:56', 1, 52661, 52661, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 5000),
(217, 1, 14, '200', '2014-08-04 14:55:57', 1, 47822, 47822, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4839),
(218, 1, 14, '200', '2014-08-04 14:55:59', 1, 47683, 47683, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -139),
(219, 1, 14, '200', '2014-08-04 14:56:00', 1, 47655, 47655, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -28),
(220, 2, 14, '200', '2014-08-04 14:56:04', 1, 56882, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 68),
(221, 1, 15, '200', '2014-08-04 14:56:05', 1, 47658, 47658, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -59);
INSERT INTO `check_log` (`id_check_log`, `id_application`, `id_platform`, `HTTP_code`, `date_check`, `id_user`, `size_download`, `download_content_length`, `redirect_url`, `request_header`, `weight_diff`) VALUES
(222, 2, 11, '200', '2014-08-04 14:56:08', 1, 56814, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', -64),
(223, 1, 11, '200', '2014-08-04 14:56:09', 1, 47771, 47771, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -22),
(224, 1, 10, '200', '2014-08-04 14:56:09', 1, 47826, 47826, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 173),
(225, 1, 10, '200', '2014-08-04 14:56:12', 1, 47701, 47701, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -125),
(226, 1, 11, '200', '2014-08-04 14:56:13', 1, 47751, 47751, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -20),
(227, 2, 11, '200', '2014-08-04 14:56:15', 1, 56814, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 0),
(228, 1, 9, '200', '2014-08-04 14:56:23', 1, 47844, 47844, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ LG Browser/5.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT4; 09.00.00; 0x00000001;); LG NetCast.TV-2012\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 47844),
(229, 1, 8, '200', '2014-08-04 14:56:24', 1, 47685, 47685, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; U; Linux mips; en) AppleWebKit/531.2+ (KHTML, like Gecko, Safari/531.2+); LG Browser/4.0.9(+mouse+3D+SCREEN+TUNER; LGE; 42LE7500-ZA; 03.05.04; 0x00000001;); LG NetCast.TV-2011\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 47685),
(230, 1, 8, '200', '2014-08-04 14:56:26', 1, 47720, 47720, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; U; Linux mips; en) AppleWebKit/531.2+ (KHTML, like Gecko, Safari/531.2+); LG Browser/4.0.9(+mouse+3D+SCREEN+TUNER; LGE; 42LE7500-ZA; 03.05.04; 0x00000001;); LG NetCast.TV-2011\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 35),
(231, 1, 9, '200', '2014-08-04 14:56:27', 1, 47692, 47692, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ LG Browser/5.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT4; 09.00.00; 0x00000001;); LG NetCast.TV-2012\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -152),
(232, 1, 12, '200', '2014-08-04 14:56:28', 1, 47804, 47804, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 47804),
(233, 1, 13, '200', '2014-08-04 14:56:29', 1, 47709, 47709, '', 'GET / HTTP/1.1\r\nUser-Agent: 66666\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 47709),
(234, 1, 13, '200', '2014-08-04 14:56:30', 1, 47788, 47788, '', 'GET / HTTP/1.1\r\nUser-Agent: 66666\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 79),
(235, 1, 15, '200', '2014-08-04 14:56:33', 1, 47864, 47864, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 206),
(236, 1, 14, '200', '2014-08-04 14:56:34', 1, 47835, 47835, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 180),
(237, 1, 13, '200', '2014-08-04 14:56:34', 1, 47808, 47808, '', 'GET / HTTP/1.1\r\nUser-Agent: 66666\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 20),
(238, 1, 12, '200', '2014-08-04 14:56:35', 1, 47712, 47712, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -92),
(239, 1, 11, '200', '2014-08-04 14:56:36', 1, 47674, 47674, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -77),
(240, 1, 10, '200', '2014-08-04 14:56:37', 1, 47778, 47778, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 77),
(241, 1, 9, '200', '2014-08-04 14:56:38', 1, 52553, 52553, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ LG Browser/5.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT4; 09.00.00; 0x00000001;); LG NetCast.TV-2012\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4861),
(242, 1, 8, '200', '2014-08-04 14:56:38', 1, 47697, 47697, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; U; Linux mips; en) AppleWebKit/531.2+ (KHTML, like Gecko, Safari/531.2+); LG Browser/4.0.9(+mouse+3D+SCREEN+TUNER; LGE; 42LE7500-ZA; 03.05.04; 0x00000001;); LG NetCast.TV-2011\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -23),
(243, 1, 9, '200', '2014-08-04 14:56:39', 1, 47742, 47742, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ LG Browser/5.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT4; 09.00.00; 0x00000001;); LG NetCast.TV-2012\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -4811),
(244, 1, 10, '200', '2014-08-04 14:56:40', 1, 47650, 47650, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -128),
(245, 1, 11, '200', '2014-08-04 14:56:41', 1, 47666, 47666, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -8),
(246, 1, 12, '200', '2014-08-04 14:56:42', 1, 47687, 47687, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -25),
(247, 1, 13, '200', '2014-08-04 14:56:43', 1, 52669, 52669, '', 'GET / HTTP/1.1\r\nUser-Agent: 66666\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 4861),
(248, 1, 14, '200', '2014-08-04 14:56:43', 1, 47704, 47704, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -131),
(249, 1, 15, '200', '2014-08-04 14:56:44', 1, 47748, 47748, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -116),
(250, 1, 13, '200', '2014-08-04 14:56:45', 1, 52614, 52614, '', 'GET / HTTP/1.1\r\nUser-Agent: 66666\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -55),
(251, 1, 12, '200', '2014-08-04 14:56:46', 1, 47821, 47821, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 134),
(252, 1, 10, '200', '2014-08-04 14:56:47', 1, 47643, 47643, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -7),
(253, 8, 8, '200', '2014-08-04 14:57:52', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; U; Linux mips; en) AppleWebKit/531.2+ (KHTML, like Gecko, Safari/531.2+); LG Browser/4.0.9(+mouse+3D+SCREEN+TUNER; LGE; 42LE7500-ZA; 03.05.04; 0x00000001;); LG NetCast.TV-2011\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 1448),
(254, 8, 9, '200', '2014-08-04 14:57:53', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ LG Browser/5.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT4; 09.00.00; 0x00000001;); LG NetCast.TV-2012\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 1448),
(255, 8, 10, '200', '2014-08-04 14:57:54', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: 33333\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 1448),
(256, 8, 11, '200', '2014-08-04 14:57:54', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 1448),
(257, 8, 12, '200', '2014-08-04 14:57:55', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 1448),
(258, 8, 13, '200', '2014-08-04 14:57:55', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: 66666\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 1448),
(259, 8, 14, '200', '2014-08-04 14:57:55', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 1448),
(260, 8, 15, '200', '2014-08-04 14:57:56', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 1448),
(261, 8, 11, '200', '2014-08-04 15:14:30', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(262, 8, 11, '200', '2014-08-04 15:14:32', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(263, 8, 11, '200', '2014-08-04 15:14:34', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(264, 8, 10, '200', '2014-08-04 15:14:34', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: 33333\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(265, 8, 9, '200', '2014-08-04 15:14:36', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ LG Browser/5.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT4; 09.00.00; 0x00000001;); LG NetCast.TV-2012\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(266, 8, 8, '200', '2014-08-04 15:14:37', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; U; Linux mips; en) AppleWebKit/531.2+ (KHTML, like Gecko, Safari/531.2+); LG Browser/4.0.9(+mouse+3D+SCREEN+TUNER; LGE; 42LE7500-ZA; 03.05.04; 0x00000001;); LG NetCast.TV-2011\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(267, 8, 11, '200', '2014-08-04 15:14:38', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(268, 8, 12, '200', '2014-08-04 15:14:39', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(269, 8, 13, '200', '2014-08-04 15:14:40', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: 66666\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(270, 8, 14, '200', '2014-08-04 15:14:41', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(271, 8, 15, '200', '2014-08-04 15:14:42', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=2 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(272, 8, 8, '200', '2014-08-04 15:14:53', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; U; Linux mips; en) AppleWebKit/531.2+ (KHTML, like Gecko, Safari/531.2+); LG Browser/4.0.9(+mouse+3D+SCREEN+TUNER; LGE; 42LE7500-ZA; 03.05.04; 0x00000001;); LG NetCast.TV-2011\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(273, 8, 9, '200', '2014-08-04 15:14:54', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ LG Browser/5.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT4; 09.00.00; 0x00000001;); LG NetCast.TV-2012\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(274, 8, 9, '200', '2014-08-04 15:14:55', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ LG Browser/5.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT4; 09.00.00; 0x00000001;); LG NetCast.TV-2012\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(275, 8, 10, '200', '2014-08-04 15:14:56', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: 33333\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(276, 8, 11, '200', '2014-08-04 15:14:57', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(277, 8, 12, '200', '2014-08-04 15:14:58', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(278, 8, 13, '200', '2014-08-04 15:14:58', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: 66666\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(279, 8, 14, '200', '2014-08-04 15:14:59', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(280, 8, 15, '200', '2014-08-04 15:14:59', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(281, 8, 15, '200', '2014-08-04 15:15:00', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(282, 1, 12, '200', '2014-08-04 15:16:07', 1, 47712, 47712, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -109),
(283, 1, 11, '200', '2014-08-04 18:08:20', 1, 47774, 47774, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 108),
(284, 1, 10, '200', '2014-08-04 18:08:22', 1, 47654, 47654, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 11),
(285, 1, 12, '200', '2014-08-04 18:08:24', 1, 47780, 47780, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 68),
(286, 8, 12, '200', '2014-08-04 18:08:25', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(287, 8, 11, '200', '2014-08-04 18:08:25', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(288, 2, 11, '200', '2014-08-04 18:08:29', 1, 56846, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', 32),
(289, 8, 10, '200', '2014-08-04 18:08:29', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: 33333\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(290, 8, 9, '200', '2014-08-04 18:08:30', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ LG Browser/5.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT4; 09.00.00; 0x00000001;); LG NetCast.TV-2012\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(291, 8, 8, '200', '2014-08-04 18:08:30', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (DirectFB; U; Linux mips; en) AppleWebKit/531.2+ (KHTML, like Gecko, Safari/531.2+); LG Browser/4.0.9(+mouse+3D+SCREEN+TUNER; LGE; 42LE7500-ZA; 03.05.04; 0x00000001;); LG NetCast.TV-2011\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(292, 8, 14, '200', '2014-08-04 18:08:30', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(293, 8, 15, '200', '2014-08-04 18:08:30', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(294, 1, 10, '200', '2014-08-04 18:08:46', 1, 47684, 47684, '', 'GET / HTTP/1.1\r\nUser-Agent: 33333\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', 30),
(295, 1, 11, '200', '2014-08-04 18:08:48', 1, 47671, 47671, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.yandex.ru\r\nAccept: */*\r\n\r\n', -103),
(296, 2, 11, '200', '2014-08-04 18:08:50', 1, 56776, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', -70),
(297, 8, 11, '200', '2014-08-04 18:08:51', 1, 1448, 1448, '', 'GET /apps/lgcinema/?id=211 HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: app.lgerp.ru\r\nAccept: */*\r\n\r\n', 0),
(298, 2, 11, '200', '2014-08-04 18:08:58', 1, 56764, 219, '', 'GET / HTTP/1.1\r\nUser-Agent: Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)\r\nHost: www.google.com\r\nAccept: */*\r\n\r\n', -12);

-- --------------------------------------------------------

--
-- Структура таблицы `platforms`
--

CREATE TABLE IF NOT EXISTS `platforms` (
  `id_platform` tinyint(5) NOT NULL AUTO_INCREMENT,
  `name_platform` varchar(50) NOT NULL,
  `UA_string` text NOT NULL,
  `description_platform` text NOT NULL,
  PRIMARY KEY (`id_platform`),
  UNIQUE KEY `unique_id_platform` (`id_platform`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Дамп данных таблицы `platforms`
--

INSERT INTO `platforms` (`id_platform`, `name_platform`, `UA_string`, `description_platform`) VALUES
(8, 'NetCast 2.0', 'Mozilla/5.0 (DirectFB; U; Linux mips; en) AppleWebKit/531.2+ (KHTML, like Gecko, Safari/531.2+); LG Browser/4.0.9(+mouse+3D+SCREEN+TUNER; LGE; 42LE7500-ZA; 03.05.04; 0x00000001;); LG NetCast.TV-2011', ''),
(9, 'NetCast 3.0 H12 (2012)', 'Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ LG Browser/5.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT4; 09.00.00; 0x00000001;); LG NetCast.TV-2012', ''),
(10, 'NetCast 3.0 M12 (2012)', '33333', ''),
(11, 'NetCast 4.0 H13 (2013)', 'Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)', ''),
(12, 'NetCast 4.0 M13 (2013)', 'Mozilla/5.0 (Unknown; Linux armv7l) AppleWebKit/537.1+ (KHTML, like Gecko) Safari/537.1+ LG Browser/6.00.00(+mouse+3D+SCREEN+TUNER; LGE; GLOBAL-PLAT5; 03.07.01; 0x00000001;); LG NetCast.TV-2013/03.17.01 (LG, GLOBAL-PLAT4, wired)', ''),
(13, 'NetCast 4.5 (2014)', '66666', ''),
(14, 'WebOS Full HD (FHD)', 'Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41', ''),
(15, 'webOS Ultra HD (UHD)', 'Mozilla/5.0 (Web0S; Linux/SmartTV) AppleWebKit/537.41 (KHTML, like Gecko) Large Screen WebAppManager Safari/537.41', '');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id_user` tinyint(5) NOT NULL AUTO_INCREMENT,
  `login_user` varchar(50) NOT NULL,
  `password_user` varchar(50) NOT NULL,
  `email_user` varchar(255) NOT NULL,
  `superuser` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_user`, `login_user`, `password_user`, `email_user`, `superuser`) VALUES
(1, 'admin', 'e00cf25ad42683b3df678c61f42c6bda', 'test@test.test', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
