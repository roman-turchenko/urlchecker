-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Июл 11 2014 г., 17:13
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `urlchecker`
--

-- --------------------------------------------------------

--
-- Структура таблицы `applications`
--

CREATE TABLE IF NOT EXISTS `applications` (
  `id_application` tinyint(5) NOT NULL AUTO_INCREMENT,
  `name_application` varchar(255) NOT NULL,
  `url_application` varchar(255) NOT NULL,
  `description_application` text NOT NULL,
  `id_user` tinyint(5) NOT NULL,
  PRIMARY KEY (`id_application`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Дамп данных таблицы `applications`
--

INSERT INTO `applications` (`id_application`, `name_application`, `url_application`, `description_application`, `id_user`) VALUES
(16, 'Yandex', 'http://yandex.ru', 'test32', 3),
(15, 'Google', 'http://google.com', 'test', 3),
(13, 'sdfsdf', '', '', 0),
(12, 'sfsdfsdf', '', 'sdfsdfsdf', 0),
(11, 'sdfsdf', '', '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `check_log`
--

CREATE TABLE IF NOT EXISTS `check_log` (
  `id_check_log` int(11) NOT NULL AUTO_INCREMENT,
  `id_application` tinyint(5) NOT NULL,
  `id_platform` tinyint(5) NOT NULL,
  `HTTP_code` varchar(255) NOT NULL,
  `date_check` datetime NOT NULL,
  PRIMARY KEY (`id_check_log`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `platforms`
--

CREATE TABLE IF NOT EXISTS `platforms` (
  `id_platform` tinyint(5) NOT NULL AUTO_INCREMENT,
  `name_platform` varchar(50) NOT NULL,
  `UA_string` text NOT NULL,
  `description_platform` text NOT NULL,
  PRIMARY KEY (`id_platform`),
  UNIQUE KEY `unique_id_platform` (`id_platform`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `platforms`
--

INSERT INTO `platforms` (`id_platform`, `name_platform`, `UA_string`, `description_platform`) VALUES
(1, 'NetCast', 'asdasd', ''),
(2, 'Webos', 'asdfasfafa', '');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id_user` tinyint(5) NOT NULL AUTO_INCREMENT,
  `login_user` varchar(50) NOT NULL,
  `password_user` varchar(50) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_user`, `login_user`, `password_user`) VALUES
(1, 'admin', 'e00cf25ad42683b3df678c61f42c6bda'),
(3, 'admin', 'c84258e9c39059a89ab77d846ddab909');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
